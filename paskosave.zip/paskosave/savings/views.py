from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Payment, FamilyMember, ContributionDay, ActivityLog
from .services import (
    apply_payment,
    revert_payment,
    get_coverable_days,
    generate_contribution_days,
    sync_contribution_days_to_range,
)
from urllib.parse import unquote
from datetime import timedelta, date
from .config import START_DATE, END_DATE
from django.db.models import Sum, Value, Count, Q, DecimalField
import base64
from django.core.files.base import ContentFile
import calendar
from decimal import Decimal
from django.http import HttpResponse
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from django.db.models.functions import Coalesce
from django.utils.timezone import now
from django.utils import timezone
import os
from django.conf import settings
from django.views.decorators.http import require_POST

def log_activity(request, action):
    ActivityLog.objects.create(
        user=request.user,
        action=action
    )

def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Invalid username or password")

    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def admin_dashboard(request):
    today = date.today()

    members = FamilyMember.objects.all()

    # 🟢 TOP MEMBER (highest % of their own contribution days paid)
    top_member = None
    best_ratio = -1

    for member in members:
        member_total_days = ContributionDay.objects.filter(member=member).count()
        member_paid_days = ContributionDay.objects.filter(
            member=member,
            status='PAID'
        ).count()

        ratio = (member_paid_days / member_total_days) if member_total_days else 0

        member.paid_days = member_paid_days
        member.completion_pct = round(ratio * 100, 1)

        if ratio > best_ratio:
            best_ratio = ratio
            top_member = member

    # 🔴 BEHIND MEMBERS (per-member cycle, not the global one)
    behind_members = []

    for member in members:
        effective_today = min(today, member.end_date)

        if effective_today < member.start_date:
            expected_days = 0
        else:
            expected_days = 0
            current = member.start_date

            while current <= effective_today:
                if current.weekday() != 6:  # 6 = Sunday
                    expected_days += 1
                current += timedelta(days=1)

        paid_qs = ContributionDay.objects.filter(
            member=member,
            status='PAID',
            date__gte=member.start_date,
            date__lte=member.end_date
        )

        paid_days = 0

        for p in paid_qs:
            d = p.date
            if hasattr(d, "date"):
                d = d.date()

            if d.weekday() != 6:
                paid_days += 1
        missed_days = max(expected_days - paid_days, 0)

        member.missed_days = missed_days

        # only add members who are actually behind
        if missed_days > 0:
            behind_members.append(member)

    # sort worst first
    behind_members.sort(key=lambda x: x.missed_days, reverse=True)

    # 🟡 MOST BEHIND MEMBER
    most_behind_member = max(
        behind_members,
        key=lambda x: x.missed_days,
        default=None
    )

    # 💰 TOTAL SAVINGS
    total_savings = Payment.objects.aggregate(
        total=Coalesce(Sum('amount'), Decimal('0.00'))
    )['total']

    # 📅 TODAY STATUS
    paid_today = 0
    unpaid_today = 0

    for member in members:
        today_record = ContributionDay.objects.filter(
            member=member,
            date=today
        ).first()

        if today_record and today_record.status == "PAID":
            member.today_status = "PAID"
            paid_today += 1
        else:
            member.today_status = "UNPAID"
            unpaid_today += 1

    total_members = members.count()
    return render(request, 'dashboard.html', {
        'members': members,
        'total_savings': total_savings,
        'top_member': top_member,
        'behind_members': behind_members,
        'most_behind_member': most_behind_member,
        'paid_today': paid_today,
        'unpaid_today': unpaid_today,
        'total_members': total_members,
    })

@login_required
def add_member(request):
    members = FamilyMember.objects.all().order_by('-created_at')

    if request.method == "POST":
        name = request.POST.get('name')
        daily_rate_input = request.POST.get('daily_rate')
        start_date_input = request.POST.get('start_date')
        end_date_input = request.POST.get('end_date')

        if name:
            daily_rate = Decimal(str(daily_rate_input or "5.00"))

            member_start = (
                date.fromisoformat(start_date_input) if start_date_input else START_DATE
            )
            member_end = (
                date.fromisoformat(end_date_input) if end_date_input else END_DATE
            )

            if member_end < member_start:
                messages.error(request, "End date must be on or after the start date.")
                return redirect('add_member')

            member = FamilyMember.objects.create(
                name=name,
                daily_rate=daily_rate,
                start_date=member_start,
                end_date=member_end
            )

            generate_contribution_days(member)

            log_activity(
                request,
                f"Added member {member.name}"
            )

            return redirect('add_member')

    return render(request, 'add_member.html', {
        'members': members,
        'default_start_date': START_DATE,
        'default_end_date': END_DATE,
    })

@login_required
def edit_member(request, member_id):
    member = get_object_or_404(FamilyMember, id=member_id)

    if request.method == "POST":
        name = request.POST.get("name")
        daily_rate_input = request.POST.get("daily_rate")
        start_date_input = request.POST.get("start_date")
        end_date_input = request.POST.get("end_date")

        if name:
            member.name = name

        if daily_rate_input:
            new_rate = Decimal(str(daily_rate_input))

            if member.daily_rate != new_rate:
                member.daily_rate = new_rate

                # Update ALL unpaid days to the new rate
                # Paid days remain historical and unchanged
                ContributionDay.objects.filter(
                    member=member,
                    status='UNPAID',
                ).update(
                    daily_rate=new_rate
                )

        new_start = date.fromisoformat(start_date_input) if start_date_input else member.start_date
        new_end = date.fromisoformat(end_date_input) if end_date_input else member.end_date

        if new_end < new_start:
            messages.error(request, "End date must be on or after the start date.")
            return redirect('add_member')

        dates_changed = (new_start != member.start_date) or (new_end != member.end_date)

        member.start_date = new_start
        member.end_date = new_end
        
        member.save()
        log_activity(
            request,
            f"Updated member {member.name}"
        )

        if dates_changed:
            # Adds missing days inside the new range, and drops UNPAID
            # days that fall outside of it. PAID days are never touched.
            sync_contribution_days_to_range(member)

        return redirect('add_member')

    return redirect('add_member')

@login_required
@require_POST
def delete_member(request, member_id):
    member = get_object_or_404(FamilyMember, id=member_id)

    member_name = member.name

    log_activity(
        request,
        f"Deleted member {member_name}"
    )
    member.delete()
    return redirect('add_member')

@login_required
def add_payment(request):
    members = FamilyMember.objects.all()

    if request.method == "POST":
        member_id = request.POST.get('member_id')
        amount_input = request.POST.get('amount')
        notes = request.POST.get('notes')
        signature_data = request.POST.get('signature')

        member = get_object_or_404(FamilyMember, id=member_id)
        amount = Decimal(str(amount_input or "0.00"))

        next_day = ContributionDay.objects.filter(
            member=member,
            status='UNPAID'
        ).order_by('date').first()

        if not next_day:
            messages.error(request, "This member has no unpaid contribution days.")
            return redirect('add_payment')

        days_to_pay, remaining_amount = get_coverable_days(member, amount)

        if not days_to_pay:
            messages.error(
                request,
                f"Minimum payment is ₱{next_day.daily_rate}"
            )
            return redirect('add_payment')

        if remaining_amount != Decimal("0.00"):
            messages.error(
                request,
                "Amount must exactly match the total of one or more unpaid days."
            )
            return redirect('add_payment')

        payment = Payment.objects.create(
            member=member,
            amount=amount,
            notes=notes
        )
        log_activity(
            request,
            f"Added payment of ₱{payment.amount} for {payment.member.name}"
        )
        if signature_data:
            format, imgstr = signature_data.split(';base64,')
            ext = format.split('/')[-1]

            payment.signature.save(
                f"signature_{payment.id}.{ext}",
                ContentFile(base64.b64decode(imgstr)),
                save=True
            )

        try:
            apply_payment(payment)
        except ValueError as error:
            payment.delete()
            messages.error(request, str(error))
            return redirect('add_payment')

        messages.success(request, "Payment successfully added!")
        return redirect('member_profile', member_id=member.id)

    return render(request, 'add_payment.html', {
        'members': members
    })

@login_required
def member_profile(request, member_id):
    member = get_object_or_404(FamilyMember, id=member_id)
    today = date.today()

    contribution_days = ContributionDay.objects.filter(
        member=member
    )

    total_paid = Payment.objects.filter(
        member=member
    ).aggregate(
        total=Sum('amount')
    )['total'] or Decimal("0.00")

    payments = Payment.objects.filter(
        member=member
    ).annotate(
        covered_days=Count(
            'contributionday',
            filter=Q(contributionday__status='PAID')
        )
    ).order_by('-payment_date')

    days_paid = contribution_days.filter(
        status='PAID'
    ).count()

    missed_qs = contribution_days.filter(
        status='UNPAID',
        date__lte=today
    )
    
    missed_days = missed_qs.count()

    missed_amount = missed_qs.aggregate(
        total=Sum('daily_rate')
    )['total'] or Decimal("0.00")

    month = int(request.GET.get('month', today.month))
    year = int(request.GET.get('year', today.year))

    if year < member.start_date.year:
        year = member.start_date.year
        month = member.start_date.month

    if year > member.end_date.year:
        year = member.end_date.year
        month = member.end_date.month

    cal = calendar.monthcalendar(year, month)

    month_contributions = ContributionDay.objects.filter(
        member=member,
        date__year=year,
        date__month=month
    )

    contribution_map = {
        contribution.date: contribution
        for contribution in month_contributions
    }

    calendar_weeks = []

    for week in cal:
        week_data = []

        for day_num in week:
            if day_num == 0:
                week_data.append(None)
                continue

            current_date = date(year, month, day_num)

            if current_date.weekday() == 6:
                week_data.append({
                    "day": day_num,
                    "date": current_date,
                    "status": "SUNDAY",
                    "rate": Decimal("0.00")
                })
                continue

            contribution = contribution_map.get(current_date)

            week_data.append({
                "day": day_num,
                "date": current_date,
                "status": contribution.status if contribution else "UNPAID",
                "rate": contribution.daily_rate if contribution else Decimal("0.00")
            })

        calendar_weeks.append(week_data)

    prev_month = month - 1
    prev_year = year

    if prev_month < 1:
        prev_month = 12
        prev_year -= 1

    next_month = month + 1
    next_year = year

    if next_month > 12:
        next_month = 1
        next_year += 1

    return render(request, 'profile.html', {
        'member': member,

        'total_paid': total_paid,
        'days_paid': days_paid,
        'missed_days': missed_days,
        'missed_amount': missed_amount,

        'payments': payments,

        'calendar_weeks': calendar_weeks,
        'month_name': calendar.month_name[month],
        'month': month,
        'year': year,

        'prev_month': prev_month,
        'prev_year': prev_year,
        'next_month': next_month,
        'next_year': next_year,
    })
@login_required
def payment_history(request):
    payments = Payment.objects.select_related(
        'member'
    ).annotate(
        covered_days=Count(
            'contributionday',
            filter=Q(contributionday__status='PAID')
        )
    ).order_by('-payment_date')

    total_collected = Payment.objects.aggregate(
        total=Sum('amount')
    )['total'] or 0

    total_transactions = Payment.objects.count()

    return render(request, 'payment_history.html', {
        'payments': payments,
        'total_collected': total_collected,
        'total_transactions': total_transactions,
    })
@login_required
@require_POST
def delete_payment(request, payment_id):
    payment = get_object_or_404(Payment, id=payment_id)

    # 1. REVERT contribution days first
    revert_payment(payment)

    log_activity(
        request,
        f"Deleted payment of ₱{payment.amount} for {payment.member.name}"
    )
    # 2. DELETE payment
    payment.delete()
    
    messages.success(request, "Deleted successfully!")
    return redirect('payment_history')

def link_callback(uri, rel):
    uri = unquote(uri)

    if uri.startswith(settings.MEDIA_URL):
        path = os.path.join(settings.MEDIA_ROOT, uri.replace(settings.MEDIA_URL, ""))

    elif uri.startswith(settings.STATIC_URL):
        path = os.path.join(settings.STATIC_ROOT, uri.replace(settings.STATIC_URL, ""))

        if not os.path.exists(path) and hasattr(settings, "STATICFILES_DIRS"):
            for static_dir in settings.STATICFILES_DIRS:
                possible_path = os.path.join(
                    static_dir,
                    uri.replace(settings.STATIC_URL, "")
                )

                if os.path.exists(possible_path):
                    path = possible_path
                    break

    else:
        return uri

    if not os.path.isfile(path):
        raise Exception(f"Media file not found: {path}")

    return path

@login_required
def export_member_pdf(request, member_id):
    member = get_object_or_404(FamilyMember, id=member_id)
    today = timezone.localdate()

    try:
        month = int(request.GET.get("month", today.month))
        year = int(request.GET.get("year", today.year))

        if month < 1 or month > 12:
            month = today.month

    except ValueError:
        month = today.month
        year = today.year

    contribution_days = ContributionDay.objects.filter(member=member)

    total_paid = Payment.objects.filter(
        member=member
    ).aggregate(
        total=Sum("amount")
    )["total"] or Decimal("0.00")

    days_paid = contribution_days.filter(
        status="PAID"
    ).count()

    due_until = min(today, member.end_date)

    due_contributions = contribution_days.filter(
        date__lte=due_until
    )

    expected_amount = due_contributions.aggregate(
        total=Sum("daily_rate")
    )["total"] or Decimal("0.00")

    missed_qs = contribution_days.filter(
        status="UNPAID",
        date__lte=today
    )

    missed_days = missed_qs.count()

    missed_amount = missed_qs.aggregate(
        total=Sum("daily_rate")
    )["total"] or Decimal("0.00")

    remaining_balance = expected_amount - total_paid

    if remaining_balance < Decimal("0.00"):
        remaining_balance = Decimal("0.00")

    payments = Payment.objects.filter(
        member=member
    ).annotate(
        covered_days=Count(
            "contributionday",
            filter=Q(contributionday__status="PAID"),
            distinct=True
        )
    ).order_by("-payment_date")

    cal = calendar.monthcalendar(year, month)

    month_contributions = ContributionDay.objects.filter(
        member=member,
        date__year=year,
        date__month=month
    )

    contribution_map = {
        contribution.date: contribution
        for contribution in month_contributions
    }

    calendar_weeks = []

    for week in cal:
        week_data = []

        for day_num in week:
            if day_num == 0:
                week_data.append(None)
                continue

            current_date = timezone.datetime(year, month, day_num).date()

            if (
                current_date.weekday() == 6
                or current_date < member.start_date
                or current_date > member.end_date
            ):
                week_data.append({
                    "day": day_num,
                    "status": "NO_DUE",
                    "rate": Decimal("0.00")
                })
                continue

            contribution = contribution_map.get(current_date)

            if contribution:
                status = contribution.status
                rate = contribution.daily_rate
            else:
                if current_date > today:
                    status = "PENDING"
                else:
                    status = "UNPAID"

                rate = member.daily_rate

            week_data.append({
                "day": day_num,
                "status": status,
                "rate": rate
            })

        calendar_weeks.append(week_data)

    html = render_to_string("member_pdf.html", {
        "member": member,
        "payments": payments,
        "total_payments": payments.count(),

        "total_paid": total_paid,
        "days_paid": days_paid,
        "missed_days": missed_days,
        "missed_amount": missed_amount,
        "expected_amount": expected_amount,
        "remaining_balance": remaining_balance,

        "calendar_weeks": calendar_weeks,
        "month_name": calendar.month_name[month],
        "month": month,
        "year": year,
        "report_date": today,
    })

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = f'inline; filename="{member.name}_report.pdf"'

    pisa_status = pisa.CreatePDF(
        html,
        dest=response,
        link_callback=link_callback,
        encoding="UTF-8"
    )

    if pisa_status.err:
        return HttpResponse("Error generating PDF", status=500)

    return response

@login_required
def report_page(request):

    month = request.GET.get('month')

    if month and month != "None":
        selected_month = int(month)
    else:
        selected_month = None

    selected_year = int(
        request.GET.get('year', date.today().year)
    )

    # PAYMENT QUERY
    payments = Payment.objects.filter(
        payment_date__year=selected_year
    )

    if selected_month:
        payments = payments.filter(
            payment_date__month=selected_month
        )

    total_savings = (
        payments.aggregate(
            total=Sum('amount')
        )['total']
        or Decimal("0.00")
    )

    total_members = FamilyMember.objects.count()

    # CONTRIBUTION QUERY
    contributions = ContributionDay.objects.filter(
        date__year=selected_year
    )

    if selected_month:
        contributions = contributions.filter(
            date__month=selected_month
        )

    expected_collection = (
        contributions.aggregate(
            total=Sum('daily_rate')
        )['total']
        or Decimal("0.00")
    )

    remaining_balance = expected_collection - total_savings

    member_reports = []

    for member in FamilyMember.objects.all():

        member_payments = Payment.objects.filter(
            member=member,
            payment_date__year=selected_year
        )

        if selected_month:
            member_payments = member_payments.filter(
                payment_date__month=selected_month
            )

        total_paid = (
            member_payments.aggregate(
                total=Sum('amount')
            )['total']
            or Decimal("0.00")
        )

        member_contributions = ContributionDay.objects.filter(
            member=member,
            date__year=selected_year
        )

        if selected_month:
            member_contributions = member_contributions.filter(
                date__month=selected_month
            )

        days_covered = member_contributions.filter(
            status='PAID'
        ).count()

        missed_days = member_contributions.filter(
            status='UNPAID'
        ).count()

        expected_amount = (
            member_contributions.aggregate(
                total=Sum('daily_rate')
            )['total']
            or Decimal("0.00")
        )

        member_reports.append({
            'member': member,
            'total_paid': total_paid,
            'expected_amount': expected_amount,
            'days_covered': days_covered,
            'missed_days': missed_days,
            'remaining_balance': expected_amount - total_paid,
        })

    return render(request, 'report.html', {
        'total_savings': total_savings,
        'total_members': total_members,
        'expected_collection': expected_collection,
        'remaining_balance': remaining_balance,
        'member_reports': member_reports,
        'selected_month': selected_month,
        'selected_year': selected_year,
        'report_generated_at': timezone.now(),
    })

@login_required
def export_report_pdf(request):

    month = request.GET.get('month')

    if month and month != "None":
        selected_month = int(month)
    else:
        selected_month = None

    selected_year = int(
        request.GET.get('year', date.today().year)
    )

    payments = Payment.objects.filter(
        payment_date__year=selected_year
    )

    if selected_month:
        payments = payments.filter(
            payment_date__month=selected_month
        )

    total_savings = (
        payments.aggregate(
            total=Sum('amount')
        )['total']
        or Decimal("0.00")
    )

    total_members = FamilyMember.objects.count()

    contributions = ContributionDay.objects.filter(
        date__year=selected_year
    )

    if selected_month:
        contributions = contributions.filter(
            date__month=selected_month
        )

    expected_collection = (
        contributions.aggregate(
            total=Sum('daily_rate')
        )['total']
        or Decimal("0.00")
    )

    remaining_balance = expected_collection - total_savings

    member_reports = []

    for member in FamilyMember.objects.all():

        member_payments = Payment.objects.filter(
            member=member,
            payment_date__year=selected_year
        )

        if selected_month:
            member_payments = member_payments.filter(
                payment_date__month=selected_month
            )

        total_paid = (
            member_payments.aggregate(
                total=Sum('amount')
            )['total']
            or Decimal("0.00")
        )

        member_contributions = ContributionDay.objects.filter(
            member=member,
            date__year=selected_year
        )

        if selected_month:
            member_contributions = member_contributions.filter(
                date__month=selected_month
            )

        days_covered = member_contributions.filter(
            status='PAID'
        ).count()

        missed_days = member_contributions.filter(
            status='UNPAID'
        ).count()

        expected_amount = (
            member_contributions.aggregate(
                total=Sum('daily_rate')
            )['total']
            or Decimal("0.00")
        )

        member_reports.append({
            'member': member,
            'total_paid': total_paid,
            'expected_amount': expected_amount,
            'days_covered': days_covered,
            'missed_days': missed_days,
            'remaining_balance': expected_amount - total_paid,
        })

    html = render_to_string(
        'report_pdf.html',
        {
            'total_savings': total_savings,
            'total_members': total_members,
            'expected_collection': expected_collection,
            'remaining_balance': remaining_balance,
            'member_reports': member_reports,
            'selected_month': selected_month,
            'selected_year': selected_year,
            'report_generated_at': timezone.now(),
        }
    )

    response = HttpResponse(
        content_type='application/pdf'
    )

    response['Content-Disposition'] = (
        'inline; filename="report.pdf"'
    )

    pisa.CreatePDF(
        html,
        dest=response
    )

    return response

def activity_logs(request):
    logs = ActivityLog.objects.select_related(
        'user'
    ).order_by('-created_at')

    return render(
        request,
        'activity_logs.html',
        {
            'logs': logs
        }
    )
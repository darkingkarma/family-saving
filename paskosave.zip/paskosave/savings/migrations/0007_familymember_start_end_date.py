from datetime import date

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('savings', '0006_alter_contributionday_daily_rate'),
    ]

    operations = [
        migrations.AddField(
            model_name='familymember',
            name='start_date',
            field=models.DateField(
                default=date(2026, 6, 1),
                help_text='First day this member is expected to contribute.',
            ),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='familymember',
            name='end_date',
            field=models.DateField(
                default=date(2026, 12, 20),
                help_text='Last day this member is expected to contribute.',
            ),
            preserve_default=False,
        ),
    ]

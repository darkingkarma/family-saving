from django.db import migrations

def fill_daily_rate(apps, schema_editor):
    ContributionDay = apps.get_model('savings', 'ContributionDay')

    for c in ContributionDay.objects.all():
        if c.daily_rate is None:
            c.daily_rate = c.member.daily_rate
            c.save()

class Migration(migrations.Migration):

    dependencies = [
        ('savings', '0004_contributionday_daily_rate'),
    ]

    operations = [
        migrations.RunPython(fill_daily_rate),
    ]
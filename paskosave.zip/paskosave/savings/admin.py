from django.contrib import admin
from .models import FamilyMember, Payment, ContributionDay


@admin.register(FamilyMember)
class FamilyMemberAdmin(admin.ModelAdmin):
    list_display = ('name', 'daily_rate', 'start_date', 'end_date', 'created_at')


admin.site.register(Payment)
admin.site.register(ContributionDay)
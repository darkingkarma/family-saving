from datetime import date

START_DATE = date(2026, 6, 1)
END_DATE = date(2026, 12, 20)
from django.db import models
from django.contrib.auth.models import User

class FamilyMember(models.Model):
    name = models.CharField(max_length=100)
    daily_rate = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=5
    )
    start_date = models.DateField(
        help_text="First day this member is expected to contribute."
    )
    end_date = models.DateField(
        help_text="Last day this member is expected to contribute."
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Payment(models.Model):
    member = models.ForeignKey(
        FamilyMember,
        on_delete=models.CASCADE
    )

    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    payment_date = models.DateTimeField(auto_now_add=True)

    signature = models.ImageField(
        upload_to='signatures/',
        blank=True,
        null=True
    )

    notes = models.TextField(
        blank=True,
        null=True
    )

    def __str__(self):
        return f"{self.member.name} - ₱{self.amount}"

class ContributionDay(models.Model):
    STATUS_CHOICES = [
        ('PAID', 'Paid'),
        ('UNPAID', 'Unpaid'),
    ]

    member = models.ForeignKey(
        FamilyMember,
        on_delete=models.CASCADE
    )

    date = models.DateField()

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='UNPAID'
    )

    payment = models.ForeignKey(
        'Payment',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    daily_rate = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=False,
        blank=True
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['member', 'date'],
                name='unique_member_date'
            )
        ]

    def __str__(self):
        return f"{self.member.name} - {self.date} ({self.status})"

#trying
class ActivityLog(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    action = models.CharField(max_length=255)

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.action
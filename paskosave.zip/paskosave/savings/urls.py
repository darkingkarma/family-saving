from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('add-member/', views.add_member, name='add_member'),
    path('edit-member/<int:member_id>/', views.edit_member, name='edit_member'),
    path('delete-member/<int:member_id>/', views.delete_member, name='delete_member'),
    path('add-payment/', views.add_payment, name='add_payment'),
    path('profile/<int:member_id>/', views.member_profile, name='member_profile'),
    path('payment-history/', views.payment_history, name='payment_history'),
    path('delete-payment/<int:payment_id>/', views.delete_payment, name='delete_payment'),
    path('export-member-pdf/<int:member_id>/', views.export_member_pdf, name='export_member_pdf'),
    path('report/', views.report_page, name='report_page'),
    path('export-report-pdf/', views.export_report_pdf, name='export_report_pdf'),
    path('activity-logs/', views.activity_logs, name='activity_logs'),
]
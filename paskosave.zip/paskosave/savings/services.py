from datetime import timedelta

from .models import ContributionDay
from decimal import Decimal


def generate_contribution_days(member):
    """
    Create UNPAID ContributionDay rows for every non-Sunday between
    member.start_date and member.end_date (inclusive) that doesn't
    already have a row. Safe to call multiple times.
    """
    existing_dates = set(
        ContributionDay.objects.filter(member=member).values_list('date', flat=True)
    )

    current = member.start_date
    new_days = []

    while current <= member.end_date:
        if current.weekday() != 6 and current not in existing_dates:
            new_days.append(
                ContributionDay(
                    member=member,
                    date=current,
                    status='UNPAID',
                    daily_rate=member.daily_rate
                )
            )
        current += timedelta(days=1)

    if new_days:
        ContributionDay.objects.bulk_create(new_days)


def sync_contribution_days_to_range(member):
    """
    Reconciles a member's ContributionDay rows with their current
    start_date/end_date after those dates have changed.

    - Adds any missing non-Sunday days inside the (new) range.
    - Removes UNPAID days that now fall outside the range.
    - Never touches PAID days, even if they fall outside the new range,
      so payment history is never silently deleted.
    """
    ContributionDay.objects.filter(
        member=member,
        status='UNPAID'
    ).exclude(
        date__gte=member.start_date,
        date__lte=member.end_date
    ).delete()

    generate_contribution_days(member)


def get_coverable_days(member, amount):
    remaining_amount = Decimal(str(amount))

    unpaid_days = ContributionDay.objects.filter(
        member=member,
        status='UNPAID'
    ).order_by('date')

    days_to_pay = []

    for day in unpaid_days:
        rate = Decimal(str(day.daily_rate))

        if remaining_amount >= rate:
            days_to_pay.append(day)
            remaining_amount -= rate
        else:
            break

    return days_to_pay, remaining_amount


def apply_payment(payment):
    days_to_pay, remaining_amount = get_coverable_days(
        payment.member,
        payment.amount
    )

    if not days_to_pay:
        raise ValueError("Payment amount is lower than the next unpaid day rate.")

    if remaining_amount != Decimal("0.00"):
        raise ValueError("Payment amount must exactly match the total of unpaid day rates.")

    for day in days_to_pay:
        day.status = 'PAID'
        day.payment = payment
        day.save(update_fields=['status', 'payment'])


def revert_payment(payment):
    paid_days = ContributionDay.objects.filter(
        payment=payment
    )

    for day in paid_days:
        day.status = 'UNPAID'
        day.payment = None
        day.save(update_fields=['status', 'payment'])